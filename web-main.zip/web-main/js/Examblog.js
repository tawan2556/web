function setting(){
       document.querySelector('.copyright').innerHTML = "Copyright  @ Examblog Created by <a href="https://www.facebook.com/groups/exambloggas"
        target="_blank"><i class="fa-brands fa-facebook fa-2x"></i></a>"
    }

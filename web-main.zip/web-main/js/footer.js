function setconfig(){
      const dd = new Date()
      document.querySelector('.copyleft').innerHTML = "Copyright  <img src='https://mirrors.creativecommons.org/presskit/icons/heart.red.png' width='25' height='25' alt='cc'> @DDDD Created by <a href='https://xxxx.blogspot.com' target='_blank'>xxxx.</a>"
    }
function setFooter(){
  document.getElementById('copyright').innerHTML = '<div class="text-center"><a href="https://www.facebook.com/groups/exambloggas" target="_blank"><i class="fa-brands fa-facebook fa-2x"></i></a></div><center style="font-size:12px;">Examblog &copy; 2023 <a style="color:gray;text-decoration:none" href="https://examblog64.krooluang.com/p/examvip.html" target="_blank"> Contact</a></center>'
  }
